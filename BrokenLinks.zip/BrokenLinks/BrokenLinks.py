# import required module
import os
import urllib.request
import requests
from openpyxl import load_workbook
import pandas as pd
import openpyxl
import xlsxwriter
import fitz # PyMuPDF
import os
from openpyxl.utils.dataframe import dataframe_to_rows

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

# assign directory
directory = r'C:\Users\rbijivemula\Documents\BrokenLinks'

# iterate over files in
# that directory
for root, dirs, files in os.walk(directory):
    for filename in files:
        
        if filename.endswith(".pdf"):
            file=os.path.join(root, filename)
            print('*'*40)
            #print(f"{bcolors.OKGREEN}INFO: Working on : {file} {bcolors.ENDC}")
            print(f"INFO: Working on---------> {file} ")
            print('*'*40)
            #file=filename
            #file=r'C:\Users\rbijivemula\Documents\BrokenLinks\Dummy.pdf'
            OpFile='write_list_doc-pdf.xlsx'
            workbook = xlsxwriter.Workbook(OpFile)
            worksheet = workbook.add_worksheet()

            urls=[]
            code=[]
            page_num=[]
            link_Text=[]
            SpecificFile=[]
            ErrorMsg=[]
            StatusList=[]

            def get_status_code(url):
                requests.packages.urllib3.disable_warnings()
                result = requests.get(url, verify=False)
                return result.status_code

            ResponceStatus = {200 : 'Successfully Launched',
                             401 : 'Unauthorized Access',
                             500 : 'Unexpected Server Error',
                             999 : 'Non Standard Error Code'
                            }

            # file name with extension
            file_name = os.path.basename(file)

            # file name without extension
            #MyFile = os.path.splitext(file_name)[0]
            MyFile=file_name.split('\\')[-1]

            with fitz.open(file) as mypdf:
                #print(file)
                for page_number in range(1,len(mypdf)+1):
                    page=mypdf[page_number-1]
        
                    for links in page.links():
                        #print(dir(page.links()))
                        if 'uri' in links:
                            url = links['uri']
                            #print('*'*10,url)
                            ErrorCode= get_status_code(url)
                            linkText = page.get_textbox(url)
                            urls.append(url)
                            code.append(ErrorCode)
                            page_num.append(page_number)
                            SpecificFile.append(MyFile)
                            val = ResponceStatus.get(ErrorCode)
                            ErrorMsg.append(val)
                            #status = ErrorCode not in [501,999,401]
                            if ErrorCode not in [500,999] :
                                status = 'Pass'
                            else:
                                status = 'Fail'
                            StatusList.append(status)
                                                                                                 
                        else:
                            pass
        
                Data_dict = {'FileName' : SpecificFile,
                                'Page Number' : page_num,
                                'URLs' : urls,
                                'Responce Code' : code,
                                'Responce Message' : ErrorMsg,
                                'Status(Pass/Fail)' : StatusList
                                }

        

                col_num = 0
                for key, value in Data_dict.items():
                        #print(dir(worksheet))
                        #break
                    worksheet.write(0,col_num,key)
                    worksheet.write_column(1,col_num,value)
                    col_num +=1
            
            row_count = worksheet.rel_count
            print(row_count)
            workbook.close()

